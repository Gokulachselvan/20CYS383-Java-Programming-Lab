package com.amrita.jpl.cys21019.project;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * This class represents a login form for the APMS application.
 * The user can enter their username and password to login or sign up.
 * It provides functionality for handling login, signup, and forgot password actions.
 * Author: Gokulachselvan C D
 */
public class LoginForm extends JFrame {

    private JLabel usernameLabel, passwordLabel, forgotPasswordLabel;
    private JTextField usernameTextField;
    private JPasswordField passwordTextField;
    private JButton loginButton, signupButton;

    /**
     * Constructs a new LoginForm instance.
     * Initializes and configures the UI components.
     */
    public LoginForm() {
        super("APMS Login Page");

        usernameLabel = new JLabel("Username");
        passwordLabel = new JLabel("Password");
        usernameTextField = new JTextField(20);
        passwordTextField = new JPasswordField(20);
        loginButton = new JButton("Login");
        signupButton = new JButton("Sign Up");
        forgotPasswordLabel = new JLabel("<html><u>Forgot Password?</u></html>");
        forgotPasswordLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        forgotPasswordLabel.setForeground(Color.BLUE);

        JPanel contentPane = new JPanel(new GridLayout(0, 2, 20, 20));
        contentPane.add(usernameLabel);
        contentPane.add(usernameTextField);
        contentPane.add(passwordLabel);
        contentPane.add(passwordTextField);
        contentPane.add(forgotPasswordLabel); // Moved forgotPasswordLabel here
        contentPane.add(new JLabel()); // Empty label for spacing
        contentPane.add(loginButton);
        contentPane.add(signupButton);

        add(contentPane);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameTextField.getText();
                String password = new String(passwordTextField.getPassword());

                if (username.equals("admin") && password.equals("admin@123")) {
                    JOptionPane.showMessageDialog(null, "Login successful!");
                    dispose(); // Close the login form
                    // TODO: Redirect to admin dashboard
                } else if (username.equals("student") && password.equals("welcome")) {
                    JOptionPane.showMessageDialog(null, "Login successful!");
                    dispose(); // Close the login form
                    // TODO: Redirect to student dashboard
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password!");
                }
            }
        });

        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the login form
                // TODO: Redirect to signup page
            }
        });

        forgotPasswordLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                dispose(); // Close the login form
                new ForgotPasswordForm();
            }
        });

        setSize(300, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    /**
     * The entry point of the application.
     * Creates an instance of the LoginForm class.
     * @param args the command-line arguments
     */
    public static void main(String[] args) {
        new LoginForm();
    }
}
