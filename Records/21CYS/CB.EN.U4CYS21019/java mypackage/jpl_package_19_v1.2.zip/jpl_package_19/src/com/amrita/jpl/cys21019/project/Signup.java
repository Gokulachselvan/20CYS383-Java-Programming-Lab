package com.amrita.jpl.cys21019.project;

import java.io.IOException;
import java.util.Scanner;

public class Signup {

    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);

        // Get the user input
        System.out.print("Name: ");
        String name = scanner.nextLine();

        System.out.print("Password: ");
        String password = scanner.nextLine();

        System.out.print("Confirm Password: ");
        String password2 = scanner.nextLine();

        System.out.print("Phone Number: ");
        String phonenumber = scanner.nextLine();

        System.out.print("Email: ");
        String email = scanner.nextLine();

        // Validate the user input
        if (name == null || name.isEmpty()) {
            System.out.println("Name cannot be blank");
            return;
        }

        if (password.length() < 8) {
            System.out.println("Password must be at least 8 characters long");
            return;
        }

        if (!password.equals(password2)) {
            System.out.println("Passwords do not match");
            return;
        }

        if (!email.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$")) {
            System.out.println("Invalid email address");
            return;
        }

        // Create a new user
        User user = new User();
        user.setName(name);
        user.setPassword(password);
        user.setPhonenumber(phonenumber);
        user.setEmail(email);

        // Save the user to the database
        UserDAO userDAO = new UserDAO();
        userDAO.save(user);

        // Redirect the user to the home page
        System.out.println("User successfully created!");
    }
}

class User {
    private String name;
    private String password;
    private String phonenumber;
    private String email;

    public void setName(String name) {
        this.name = name;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}

class UserDAO {
    public void save(User user) {
        // TODO: Implement this method
    }
}
