package com.amrita.jpl.cys21019.project;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ForgotPasswordForm extends JFrame {

    private JLabel emailLabel, passwordLabel, confirmPasswordLabel;
    private JTextField emailTextField;
    private JPasswordField passwordTextField, confirmPasswordTextField;
    private JButton submitButton, backButton;

    public ForgotPasswordForm() {
        super("Forgot Password Form");

        emailLabel = new JLabel("Email");
        passwordLabel = new JLabel("New Password");
        confirmPasswordLabel = new JLabel("Confirm Password");
        emailTextField = new JTextField(20);
        passwordTextField = new JPasswordField(20);
        confirmPasswordTextField = new JPasswordField(20);
        submitButton = new JButton("Submit");
        backButton = new JButton("Back");

        JPanel contentPane = new JPanel(new GridLayout(0, 2, 10, 10));
        contentPane.add(emailLabel);
        contentPane.add(emailTextField);
        contentPane.add(passwordLabel);
        contentPane.add(passwordTextField);
        contentPane.add(confirmPasswordLabel);
        contentPane.add(confirmPasswordTextField);
        contentPane.add(submitButton);
        contentPane.add(backButton);

        add(contentPane);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = emailTextField.getText();
                String password = new String(passwordTextField.getPassword());
                String confirmPassword = new String(confirmPasswordTextField.getPassword());

                if (password.length() < 8) {
                    JOptionPane.showMessageDialog(null, "Password must be at least 8 characters long.");
                    return;
                } else if (!password.equals(confirmPassword)) {
                    JOptionPane.showMessageDialog(null, "Passwords do not match.");
                    return;
                } else {
                    JOptionPane.showMessageDialog(null, "Password updated! Go back to the login page");
                    dispose(); // Close the forgot password form
                    new LoginForm();
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the forgot password form
                new LoginForm();
            }
        });

        setSize(300, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new ForgotPasswordForm();
    }
}
