package com.amrita.jpl.cys21019.pract.basic;

/**
*
* @author Gokulachselvan C D
*
*/

import java.util.Scanner;

public class calc {
    public static void main(String[] args)
    {
        int a,b;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter First number:");
        a = sc.nextInt();
        //Scanner sc = new Scanner(System.in);
        System.out.println("Enter Second number:");
        b = sc.nextInt();
        System.out.println("Sum is: "+(a+b));
        System.out.println("Differnce is: "+(a-b));
        System.out.println("Product is: "+(a*b));
        System.out.println("Quotient is: "+(b/a));
        System.out.println("Remainder is: "+(a%b));
    }
}