package com.amrita.jpl.cys21019.ex;

import java.io.*;
import java.net.*;

abstract class FileTransfer {
    abstract void saveFile(byte[] fileData, String filename);

    void sendFile(String filename) {
        try {
            File file = new File(filename);
            FileInputStream fileInputStream = new FileInputStream(file);
            byte[] fileData = new byte[(int) file.length()];
            fileInputStream.read(fileData);
            fileInputStream.close();
            saveFile(fileData, filename);
        } catch (IOException e) {
            System.out.println("Error sending file: " + e.getMessage());
        }
    }
}

interface FileTransferListener {
    void onFileSent(String filename);
    void onFileSaved(String filename);
}

class FileTransferClient extends FileTransfer implements FileTransferListener {
    private Socket socket;

    public FileTransferClient() {
        try {
            socket = new Socket("localhost", 12345);
        } catch (IOException e) {
            System.out.println("Error connecting to server: " + e.getMessage());
        }
    }

    @Override
    void saveFile(byte[] fileData, String filename) {
        try {
            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
            dos.writeUTF(filename);
            dos.writeInt(fileData.length);
            dos.write(fileData);
            dos.flush();
            dos.close();
            onFileSent(filename);
        } catch (IOException e) {
            System.out.println("Error sending file: " + e.getMessage());
        }
    }

    @Override
    public void onFileSent(String filename) {
        System.out.println("File sent: " + filename);
    }

    @Override
    public void onFileSaved(String filename) {
        // Not used in the client
    }
}

class FileTransferServer extends FileTransfer implements FileTransferListener {
    private ServerSocket serverSocket;

    public FileTransferServer() {
        try {
            serverSocket = new ServerSocket(12345);
        } catch (IOException e) {
            System.out.println("Error starting server: " + e.getMessage());
        }
    }

    void start() {
        try {
            System.out.println("Server started. Waiting for incoming file transfers...");
            while (true) {
                Socket clientSocket = serverSocket.accept();
                new Thread(new ClientHandler(clientSocket)).start();
            }
        } catch (IOException e) {
            System.out.println("Error accepting client connection: " + e.getMessage());
        }
    }

    @Override
    void saveFile(byte[] fileData, String filename) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(filename);
            fileOutputStream.write(fileData);
            fileOutputStream.close();
            onFileSaved(filename);
        } catch (IOException e) {
            System.out.println("Error saving file: " + e.getMessage());
        }
    }

    @Override
    public void onFileSent(String filename) {
        // Not used in the server
    }

    @Override
    public void onFileSaved(String filename) {
        System.out.println("File saved: " + filename);
    }

    private class ClientHandler implements Runnable {
        private Socket clientSocket;

        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try {
                DataInputStream dis = new DataInputStream(clientSocket.getInputStream());
                String filename = dis.readUTF();
                int fileLength = dis.readInt();
                byte[] fileData = new byte[fileLength];
                dis.readFully(fileData);
                dis.close();
                saveFile(fileData, filename);
                clientSocket.close();
            } catch (IOException e) {
                System.out.println("Error receiving file: " + e.getMessage());
            }
        }
    }
}

public class Ftp {
    public static void main(String[] args) {
        FileTransferClient client = new FileTransferClient();
        client.sendFile("clientFile.txt");

        FileTransferServer server = new FileTransferServer();
        server.start();
    }
}
