package com.amrita.jpl.cys21019.pract;

/**
*
* @author Gokulachselvan C D
*
*/

public class pattern_print {
    public static void main(String[] args) {

        for (int i = 0; i < 4; i++) {
            System.out.println("* * * * * * ==================================");
            System.out.println("* * * * *  ===================================");
        }
        System.out.println("* * * * * * ==================================");

        for (int i = 0; i < 6; i++) {
            System.out.println("==============================================");
        }
    }
}
